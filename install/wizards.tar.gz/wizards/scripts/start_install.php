<?php

class EduSiteStartInstall
{

}