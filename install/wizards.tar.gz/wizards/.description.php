<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arWizardDescription = [
    "NAME" => "Сайт образовательной организации",
    "DESCRIPTION" => "Мастер создания сайта образовательной организации",
    "ICON" => "images/favicon.ico",
    "VERSION" => "1.0.0",
    "DEPENDENCIES" => [
        "main" => "20.0.1196",
    ],

    "STEPS_SETTINGS" => [
        "WELCOME" => [
            "CONTENT" => "Добро пожаловать в мастер создания сайта образовательной организации",
        ],
    ]
];

?>
